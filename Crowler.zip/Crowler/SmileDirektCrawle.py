import time
import openpyxl
from openpyxl import Workbook
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# ------------- Starts: Reading Excel -------------------
wb = openpyxl.Workbook()
wb = openpyxl.load_workbook(filename='policies copy.xlsm')
sheets = wb.sheetnames
ws = wb[sheets[0]]
for index in range(2,101):
	brand = ws['P2'].value
	model = ws['T2'].value+" "+ws['U2'].value
	inverhrkersetzung = ws['v2'].value
	accessories = ws['R2'].value
	leasing = ws['H2'].value
	gender = ws['J2'].value
	use = ws['I2'].value
	licenceAge = ws['K2'].value
	nat = ws['L2'].value
	bd = '01.01.1976'
	deductibleTeil = ws['N2'].value
	deductibleVoll = ws['O2'].value
	if licenceAge != '5+':
	    bd == '01.01.1996'
    
	zipcode = ws['M2'].value

	licence = '1996'
	if licenceAge != '5+':
	    licence = '2015'

#-------------- Ends: Reading Excel ---------------------

#-------------- Starts: Web Driver ----------------------
	driver = webdriver.Chrome()
	driver.get("https://app.smile-direct.ch/car?lang=de&sac=WOA")
#-------------- Ends: Web Driver ------------------------


#--------------- Stars: first submission page ------------------------------------

	checkBoxElement = driver.find_element_by_xpath("//label[@for='markeundtyp_radio']")
	markDropdown = driver.find_element_by_xpath("//select[@id='brand']")
	
	birthDate = driver.find_element_by_xpath("//input[@id='fahrzeugLenkerGeburtsdatum']")
	
	checkBoxElement.click()
	
	time.sleep(.200)
	driver.find_element_by_css_selector("select#brand > option[value='"+brand+"']").click()

	time.sleep(.280)
	driver.find_element_by_css_selector("select#type > option[value='"+model+"']").click()
	
	time.sleep(.300)
	driver.find_element_by_css_selector("select#inverkehrssetzungsJahr > option[value='2017']").click()

	time.sleep(.300)
	rowNumbers = len(driver.find_elements_by_xpath("//*[@id='modellist_tbody']/tr"))
	driver.find_element_by_xpath("//*[@id='modellist_tbody']/tr["+str(rowNumbers)+"]/td[1]/label").click()

	driver.find_element_by_id('neuwertZubehoer').send_keys(int(accessories));

	if leasing == 'yes':
	    driver.find_element_by_xpath("//label[@for='finanzierung-leasing']").click()
	    
	if gender == 'Male':
	    driver.find_element_by_xpath("//label[@for='fahrzeugLenker_geschlecht_1']").click()
	elif gender == 'Female':
	    driver.find_element_by_xpath("//label[@for='fahrzeugLenker_geschlecht_2']").click()
	    
	birthDate.send_keys(bd)

	nationality = driver.find_element_by_xpath("//select[@id='nationLenker']")

	for option in nationality.find_elements_by_tag_name('option'):
		if option.text == nat:
			option.click()
			break
	if nat != 'Schweiz':
	    driver.find_element_by_css_selector("select#bewilligungLenkerLabel > option[value='aufenthaltsbewilligung-5']").click()
	 
	    
	plz = driver.find_element_by_id('fahrzeugLenker.postleitzahl')
	plz.send_keys(int(zipcode))

	children = driver.find_element_by_id('anzahlKinder')
	children.send_keys('0')

	licenceYear = driver.find_element_by_id('datumFahrpruefungPkw')
	licenceYear.send_keys(licence)
	if  use == 'Private':
	    driver.find_element_by_xpath("//label[@for='car_private']").click()
	elif use == 'Commute':
	    driver.find_element_by_xpath("//label[@for='car_privateway']").click()
	elif use == 'Business':
	    driver.find_element_by_xpath("//label[@for='car_privatebusiness']").click()



	time.sleep(.260)
	submit = driver.find_element_by_xpath("//button[@type='submit']")
	submit.click()

#------------------------ Ends: First submission page -------------------------------------------------


#------------------------ Starts: Second submission page -----------------------------------------------
	driver.find_element_by_xpath("//label[@for='fahrzeugLenker_bussenBoolean_false']").click()
	driver.find_element_by_xpath("//label[@for='fahrzeugLenker_ausserordentlicheKuendigung_false']").click()
	driver.find_element_by_xpath("//label[@for='fahrzeugLenker_besondererSelbstbehalt_false']").click()
	driver.find_element_by_xpath("//label[@for='fahrzeugLenker_schadenfaelleBoolean_false']").click()
	driver.find_element_by_xpath("//button[@type='submit']").click()
#------------------------- Ends: Second submission page ------------------------------------------------

#------------------------- Starts: Third submission page -----------------------------------------------

#------------- starts: Outcome 1 ------------------------

	driver.find_element_by_xpath("//label[@for='haftpflicht.bonusschutz-0']").click()
	time.sleep(.250)
	driver.find_element_by_xpath("//label[@for='kaskoVersichert-0']").click()
	time.sleep(.200)
	driver.find_element_by_xpath("//label[@for='insassenUnfallVersichert-false']").click()
	time.sleep(.260)
	driver.find_element_by_xpath("//label[@for='assistanceVersichert-false']").click()
	time.sleep(.200)
	driver.find_element_by_xpath("//label[@for='haftpflicht.gFVerzicht-0']").click()
	time.sleep(.200)
	firstValue = driver.find_element_by_id('bruttopraemie')
	print(firstValue.text)

	driver.quit()
#-------------- Ends: Outcome 1 --------------------------
'''
#-------------- Starts: Outcome 2 -------------------------
	driver.find_element_by_xpath("//label[@for='kaskoVersichert-1']").click()
	time.sleep(.200)
	if deductibleTeil == 300:
	  #  driver.find_element_by_xpath("//label[@for='kaskoForm.teilkaskoSelbstbehalt-3']").click()
	    time.sleep(.200)
	elif deductibleTeil == 0:
	    driver.find_element_by_xpath("//label[@for='kaskoForm.teilkaskoSelbstbehalt-1']").click()
	    time.sleep(.300)
	driver.find_element_by_xpath("//label[@for='kaskoForm.persoenlicheEffekten-0']").click()
	firstValue = driver.find_element_by_id('bruttopraemie')
	print(firstValue.text)
	time.sleep(.200)
#-------------- Ends: Outcome 2 -------------------------

#-------------- Starts: Outcome 3 -----------------------
	driver.find_element_by_xpath("//label[@for='kasko.bonusschutz-0']").click()
	time.sleep(.200)
	driver.find_element_by_xpath("//label[@for='kaskoForm.vollkaskoSelbstbehalt-4']").click()
	time.sleep(.200)
	driver.find_element_by_xpath("//label[@for='kaskoForm.teilkaskoSelbstbehalt-4']").click()
	time.sleep(.200)
	driver.find_element_by_xpath("//label[@for='kaskoForm.parkschaeden-0']").click()
	time.sleep(.200)
	driver.find_element_by_xpath("//label[@for='kaskoForm.persoenlicheEffekten-0']").click()
	time.sleep(.200)
	firstValue = driver.find_element_by_id('bruttopraemie')
	print(firstValue.text)

#-------------- Ends: Outcome 3 -----------------------
'''
	
#-------------------------- Ends: Thirds submission page ----------------------------------------------

